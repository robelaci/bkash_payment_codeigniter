<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['bkash_credentials'] = array(
    'USER_NAME' => 'sandboxTokenizedUser02',
    'PASSWORD' => 'sandboxTokenizedUser02@12345',
    'APP_KEY' => '4f6o0cjiki2rfm34kfdadl1eqq',
    'APP_SECRET' => '2is7hdktrekvrbljjh44ll3d9l1dtjo4pasmjvs5vl5qr3fug4b'
);

